from setuptools import setup, find_packages

setup(
    name='trisight',
    version='1.0',
    author='Kaitan Sun, Gaohua Zheng',
    packages=find_packages()
)
