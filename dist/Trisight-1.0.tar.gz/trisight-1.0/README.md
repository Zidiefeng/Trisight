# Trisight

[Website](https://zidiefeng.github.io/Trisight/)

Trisight is a tool for stock analysis


## Install tools

```
pip install git+https://github.com/Zidiefeng/Trisight@dev
```

# Contributor

- Gaohua Zheng
- Zidiefeng
